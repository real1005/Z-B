module.exports = {
  products: [
    {
      id: 1,
      name: 'Thug Club TC / Blood Lazered Denim Pants',
      price: 16800,
      stock: 5,
      description: 'Thug Club FW24 Blood Lazered Denim Pants 採用 天鵝絨牛仔布，搭配 雷射水洗處理，展現獨特復古質感。背面搭配 TC 皮革標誌，並使用 TC 專屬鉚釘與鈕扣，增添品牌辨識度。'
    },
    {
      id: 2,
      name: 'Thug Club / Wind Soldier',
      price: 12800,
      stock: 8,
      description: 'Thug Club FW24 Wind Soldier 採用 C/N（棉/尼龍）混紡面料，具有 獨特水洗染色工藝，增添復古感。設計上配有 TC 標誌、前袋 TC 拉鍊、背部 T 字線條縫製，並搭配 抽繩與止滑扣，打造 寬鬆剪裁，兼具時尚與舒適度。'
    }
  ]
};
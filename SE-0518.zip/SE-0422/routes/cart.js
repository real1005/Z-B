const express = require('express');
const router = express.Router();
const { products } = require('../sharedData');

global.cartData = global.cartData || {}; // 避免 undefined

// ✅ 加入商品（若已存在則數量加一）
router.post('/', (req, res) => {
  const { productId, username } = req.body;
  const product = products.find(p => p.id === productId);
  if (!username || !product) return res.status(400).json({ error: '資料錯誤' });

  if (!global.cartData[username]) global.cartData[username] = [];

  const existingItem = global.cartData[username].find(p => p.id === productId);
  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    global.cartData[username].push({ ...product, quantity: 1 });
  }

  res.json({ success: true });
});

// ✅ 取得購物車內容
router.get('/', (req, res) => {
  const username = req.query.username;
  res.json(global.cartData[username] || []);
});

// ✅ 刪除單一商品或清空
router.delete('/', (req, res) => {
  const { username, productId } = req.body;
  if (!username) return res.status(400).json({ error: '請提供使用者名稱' });

  if (productId !== undefined) {
    // 單一商品刪除邏輯
    const cart = global.cartData[username];
    if (!cart) return res.json({ success: true }); // 購物車不存在就略過

    const index = cart.findIndex(item => item.id === productId);
    if (index !== -1) {
      if (cart[index].quantity > 1) {
        cart[index].quantity -= 1;
      } else {
        cart.splice(index, 1);
      }
    }
  } else {
    // 沒傳 productId → 清空整個購物車
    global.cartData[username] = [];
  }

  res.json({ success: true });
});

module.exports = router;
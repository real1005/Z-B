const express = require('express');
const router = express.Router();

// 初始化模擬用戶資料（可擴充）
global.users = global.users || [
  { id: 1, username: 'seller1', password: '123456', role: 'seller' },
  { id: 2, username: 'buyer1', password: '123456', role: 'buyer' }
];

// 註冊 API
router.post('/register', (req, res) => {
  const { username, password, role } = req.body;

  if (!username || !password || !role) {
    return res.status(400).json({ error: '請填寫所有欄位' });
  }

  const exists = global.users.find(u => u.username === username);
  if (exists) {
    return res.status(409).json({ error: '帳號已存在' });
  }

  const newUser = { username, password, role };
  global.users.push(newUser);

  res.json({ success: true, user: newUser });
});

// 登入 API
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  const user = global.users.find(u => u.username === username && u.password === password);
  if (!user) {
    return res.status(401).json({ error: '帳號或密碼錯誤' });
  }

  res.json({ success: true, user: { username: user.username, role: user.role } });
});

module.exports = router;
const express = require('express');
const router = express.Router();
const { products } = require('../sharedData');

// 賣家上架商品
let nextProductId = products.length + 1;

router.post('/', (req, res) => {
  const { name, price, description, username, role } = req.body;

  if (role !== 'seller') {
    return res.status(403).json({ error: '只有賣家可以新增商品' });
  }

  const newProduct = {
    id: nextProductId++,
    name,
    price,
    description: description || ''
  };

  products.push(newProduct);
  res.json({ success: true, product: newProduct });
});

module.exports = router;

// 所有人都可以查看商品列表
router.get('/', (req, res) => {
  res.json(products);
});

module.exports = router;
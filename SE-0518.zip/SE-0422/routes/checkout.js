const express = require('express');
const router = express.Router();

router.post('/', (req, res) => {
  const { username, address, paymentMethod, deliveryMethod, cartItems } = req.body;
  if (!username || !address || !paymentMethod || !deliveryMethod || !cartItems) {
    return res.status(400).json({ error: '資料不完整' });
  }
  const order = {
    id: Date.now(),
    username,
    address,
    paymentMethod,
    deliveryMethod,
    cartItems,
    createdAt: new Date()
  };
  global.orders.push(order);
  global.cartData[username] = [];
  res.json({ success: true, order });
});

module.exports = router;
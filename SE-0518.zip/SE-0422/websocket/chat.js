const { WebSocketServer } = require('ws');
const fs = require('fs');
const path = require('path');
const url = require('url');

// 關鍵字分類
const keywordsMap = {
  price: ['錢', '價錢', '價格', '售價', '要多少錢', '貴嗎', 'NT$', '元', '價位', '花費'],
  stock: ['多少', '還有幾個', '有幾件', '剩幾個', '剩下', '數量', '庫存'],
  size: ['尺寸', '大小', '規格', '長寬高', '寬度'],
  material: ['材質', '材料', '做的', '什麼布']
};

const keywordHandlers = {
  price: p => `「${p.name}」售價是 NT$${p.price}。`,
  stock: p => `「${p.name}」目前還有 ${p.stock ?? '未知'} 件庫存。`,
  size: p => p.description?.includes('尺寸') ? `尺寸資訊：${p.description}` : `沒有尺寸資訊`,
  material: p => p.description?.includes('材質') ? `材質說明：${p.description}` : `沒有提到材質`
};

module.exports = function (server, products) {
  const wss = new WebSocketServer({ noServer: true });

  // 儲存每位使用者的聊天紀錄
  const userHistories = {};

  server.on('upgrade', (req, socket, head) => {
    const { query } = url.parse(req.url, true);
    const username = query.user;

    if (!username) {
      socket.destroy();
      return;
    }

    // 通過驗證，建立 WebSocket 連線
    wss.handleUpgrade(req, socket, head, ws => {
      ws.username = username;
      wss.emit('connection', ws, req);
    });
  });

  wss.on('connection', ws => {
    const user = ws.username;
    const logsDir = path.join(__dirname, '..', 'chatlogs');
    const userFile = path.join(logsDir, `${user}.json`);

    // 初始化使用者聊天紀錄
    if (!userHistories[user]) {
      try {
        const history = fs.existsSync(userFile)
          ? JSON.parse(fs.readFileSync(userFile, 'utf-8'))
          : [];
        userHistories[user] = history;
      } catch {
        userHistories[user] = [];
      }
    }

    // 傳送使用者自己的紀錄
    userHistories[user].forEach(msg => {
      ws.send(JSON.stringify(msg));
    });

    // 接收訊息
    ws.on('message', message => {
      let data;
      try {
        data = JSON.parse(message.toString());
      } catch {
        return;
      }

      if (data.type === 'chat') {
        const msgData = {
          user: data.user,
          text: data.text,
          time: new Date().toISOString()
        };

        // 存入該使用者歷史紀錄
        userHistories[user].push(msgData);

        // 傳給自己（可改成私聊邏輯）
        if (ws.readyState === 1) {
          ws.send(JSON.stringify(msgData));
        }

        // AI 回覆
        const lowerText = data.text.toLowerCase();
        const matchedProduct = products.find(p => lowerText.includes(p.name.toLowerCase()));

        if (matchedProduct) {
          for (const [type, words] of Object.entries(keywordsMap)) {
            if (words.some(word => lowerText.includes(word))) {
              const replyText = keywordHandlers[type](matchedProduct);
              const aiMsg = {
                user: '🤖 AI助理',
                text: replyText,
                time: new Date().toISOString()
              };

              userHistories[user].push(aiMsg);
              ws.send(JSON.stringify(aiMsg));
              break;
            }
          }
        }
      }
    });

    // 儲存紀錄
    ws.on('close', () => {
      fs.mkdir(logsDir, { recursive: true }, err => {
        if (err) return console.error('❌ 建立 chatlogs 資料夾失敗:', err);

        fs.writeFile(userFile, JSON.stringify(userHistories[user], null, 2), err => {
          if (err) console.error(`❌ 儲存 ${user} 的聊天紀錄失敗:`, err);
          else console.log(`💾 使用者 ${user} 的聊天紀錄已儲存`);
        });
      });
    });
  });
};
// 簡單模擬帳號資料（未使用資料庫）
const users = [
    { username: 'buyer1', password: '1234', role: 'buyer' },
    { username: 'seller1', password: 'abcd', role: 'seller' }
  ];
  
  module.exports = users;
const express = require('express');
const http = require('http');
const path = require('path');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const { WebSocketServer } = require('ws');

const app = express();
const server = http.createServer(app);
const PORT = 3000;

// 🔗 連接 MongoDB
mongoose.connect('mongodb://localhost:27017/checkoutSystem', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// 🧾 訂單資料模型
const orderSchema = new mongoose.Schema({
  username: String,
  fullname: String,
  phone: String,
  email: String,
  deliveryMethod: String,
  paymentMethod: String,
  note: String,
  address: String,
  cardNumber: String,
  items: Array,
  createdAt: { type: Date, default: Date.now }
});

const Order = mongoose.model('Order', orderSchema);

// 🧩 中介層
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// 🌐 全域共享資料
global.users = [];
global.cartData = {};
global.orders = [];

// 📦 共享商品資料
const { products } = require('./sharedData');

// 📡 匯入 API 路由
app.use('/api/auth', require('./routes/auth'));
app.use('/api/products', require('./routes/seller'));
app.use('/api/cart', require('./routes/cart'));
app.use('/api/checkout', require('./routes/checkout'));

// 🧾 訂單 API
app.post('/api/orders', async (req, res) => {
  try {
    console.log('📥 收到訂單：', req.body);
    const newOrder = new Order(req.body);
    await newOrder.save();
    res.status(200).json({ message: '訂單已成功儲存' });
  } catch (err) {
    console.error('❌ 儲存失敗', err);
    res.status(500).json({ message: '儲存失敗', error: err });
  }
});

// 🏠 首頁導向 login.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// 🔌 啟動 WebSocket 模組
require('./websocket/chat')(server, products);

// 🚀 啟動伺服器
server.listen(PORT, () => {
  console.log(`✅ 伺服器啟動：http://localhost:${PORT}`);
});